package Exceptions;

public class wrongPasswordException  extends ErrorMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

	public wrongPasswordException() {

		super("The password is Incorrect! \n Please enter the password again!");
	}
}
