package Utils;

public enum Vehicle {
	Car, Motorcycle, Bicycle
}
