package Utils;

public enum DishType {
	Starter, Main, Dessert
}
