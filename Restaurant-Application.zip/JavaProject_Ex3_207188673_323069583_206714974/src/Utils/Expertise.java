package Utils;

public enum Expertise {
	Italien, Mediterranean, American, French, Indian, Asian
}
